package com.example.inclass11;

import android.widget.RadioGroup;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Course {

    @PrimaryKey(autoGenerate = true)
    public Long id;

    @ColumnInfo
    public String courseNumber;

    @ColumnInfo
    public String courseName;

    @ColumnInfo
    public int creditHours;

    @ColumnInfo
    public String courseGrade;


    public Course(Long id, String courseNumber, String courseName, int creditHours, String courseGrade) {
        this.id = id;
        this.courseNumber = courseNumber;
        this.courseName = courseName;
        this.creditHours = creditHours;
        this.courseGrade = courseGrade;
    }

    public Course(String courseNumber, String courseName, int creditHours, String courseGrade) {
        this.courseNumber = courseNumber;
        this.courseName = courseName;
        this.creditHours = creditHours;
        this.courseGrade = courseGrade;
    }

    public Course() {
    }

    @Override
    public String toString() {
        return "Course{" +
                "id=" + id +
                ", courseNumber='" + courseNumber + '\'' +
                ", courseName='" + courseName + '\'' +
                ", creditHours='" + creditHours + '\'' +
                ", courseGrade='" + courseGrade + '\'' +
                '}';
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCourseNumber() {
        return courseNumber;
    }

    public void setCourseNumber(String courseNumber) {
        this.courseNumber = courseNumber;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public int getCreditHours() {
        return creditHours;
    }

    public void setCreditHours(int creditHours) {
        this.creditHours = creditHours;
    }

    public String getCourseGrade() {
        return courseGrade;
    }

    public void setCourseGrade(String courseGrade) {
        this.courseGrade = courseGrade;
    }
}
