package com.example.inclass11;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity implements GradesFragment.GradeListener, AddCourseFragment.AddCourseListener {
    AppDatabase db;
    final static String TAG = "TAG_MAIN";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = Room.databaseBuilder(this, AppDatabase.class, "course.db")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();
        GradesFragment fragment = new GradesFragment();
        fragment.sendDataBaseInstance(db);
        getSupportFragmentManager().beginTransaction().add(R.id.layout, fragment).commit();
    }

    @Override
    public void gotoAddCourseFragment() {
        getSupportFragmentManager().beginTransaction().replace(R.id.layout, new AddCourseFragment()).addToBackStack(null).commit();
    }

    @Override
    public void gotoGradesFragment() {
        getSupportFragmentManager().popBackStack();
    }

    @Override
    public void gotoGradesFragment(Course course) {
        db.courseDAO().insertAll(course);
        Log.d(TAG, "gotoGradesFragment: " + db.courseDAO().getAll().toString());
        getSupportFragmentManager().popBackStack();
    }
}