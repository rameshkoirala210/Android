package com.example.inclass11;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.util.List;

public class GradesFragment extends Fragment {
    private static final String TAG = "TAG_GradesFragment";
    TextView textViewGPA, textViewHours;
    List<Course> courses;
    AppDatabase db;

    RecyclerView recyclerView;
    LinearLayoutManager mLayoutManager;
    ClassesAdapter adapter;
    public GradesFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_grades, container, false);

        textViewGPA = view.findViewById(R.id.textViewGPA);
        textViewHours = view.findViewById(R.id.textViewHours);

        courses = db.courseDAO().getAll();
        setTexViews();
        view.findViewById(R.id.buttonAddCourse).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.gotoAddCourseFragment();
            }
        });

        recyclerView = view.findViewById(R.id.recyclerView);
        adapter = new ClassesAdapter();
        mLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(adapter);
        return view;
    }

    private void setTexViews() {
        DecimalFormat decimalFormat = new DecimalFormat("#.##");
        int hour = 0;
        double totalGrade = 0;
        for(int i = 0; i < courses.size(); i++){
            hour+= courses.get(i).getCreditHours();
            double x = getGradePoint(courses.get(i));
            if (x!=-1)
                totalGrade += getGradePoint(courses.get(i));
            else
                Toast.makeText(getContext(), "GRADE IS WRONG, CHECK CODE ON ADDCOURSE", Toast.LENGTH_SHORT).show();
        }
        if (courses.size() > 0) {
            textViewHours.setText("Hours: " + hour);
            textViewGPA.setText("GPA: " + decimalFormat.format(totalGrade / hour));
        }
    }

    private double getGradePoint(Course course) {
        if (course.getCourseGrade().equals("A")) {
            return 4 * course.getCreditHours();
        } else if (course.getCourseGrade().equals("B")) {
            return 3 * course.getCreditHours();
        } else if (course.getCourseGrade().equals("C")) {
            return 2 * course.getCreditHours();
        } else if (course.getCourseGrade().equals("D")) {
            return 1 * course.getCreditHours();
        } else if (course.getCourseGrade().equals("F")) {
            return 0;
        } else
            return -1;
    }

    GradesFragment.GradeListener mListener;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener = (GradeListener) (context);
    }

    public void sendDataBaseInstance(AppDatabase db) {
        this.db = db;
    }

    interface GradeListener {
        void gotoAddCourseFragment();
    }

    private class ClassesAdapter extends RecyclerView.Adapter<ClassesAdapter.ClassHolder>{
        @NonNull
        @Override
        public ClassesAdapter.ClassHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.classes, parent, false);
            return new ClassHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ClassesAdapter.ClassHolder holder, int position) {
            holder.position = position;
            holder.setUpClasses(position);
        }

        @Override
        public int getItemCount() {
            return courses.size();
        }

        public class ClassHolder extends RecyclerView.ViewHolder {
            TextView textViewGrade,textviewCourseNumber,textViewCourseName,textViewCreditHour;
            ImageView imageViewtrash;
            int position;

            public ClassHolder(@NonNull View itemView) {
                super(itemView);
                textViewGrade = itemView.findViewById(R.id.textViewGrade);
                textviewCourseNumber = itemView.findViewById(R.id.textviewCourseNumber);
                textViewCourseName = itemView.findViewById(R.id.textViewCourseName);
                textViewCreditHour = itemView.findViewById(R.id.textViewCreditHour);
                imageViewtrash = itemView.findViewById(R.id.imageViewtrash);

            }

            public void setUpClasses(int position) {
                Course course = courses.get(position);
                textViewGrade.setText(course.getCourseGrade());
                textViewCreditHour.setText(course.getCreditHours() + "");
                textViewCourseName.setText(course.getCourseName());
                textviewCourseNumber.setText(course.getCourseNumber());
                imageViewtrash.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        db.courseDAO().delete(course);
                        courses = db.courseDAO().getAll();
                        adapter.notifyDataSetChanged();
                        setTexViews();
                    }
                });
            }
        }
    }
}