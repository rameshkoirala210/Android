package com.example.inclass11;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class AddCourseFragment extends Fragment {
    private EditText editCourseNumber, editCourseName, editCreditHours;
    private RadioGroup radioGroup;
    private RadioButton radioButton;

    public AddCourseFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_add_course, container, false);
        //Initialize views
        editCourseName = view.findViewById(R.id.editTextCourseName);
        editCourseNumber = view.findViewById(R.id.editTextCourseNumber);
        editCreditHours = view.findViewById(R.id.editTextCreditHours);
        radioGroup = view.findViewById(R.id.radioGroupGrade);

        view.findViewById(R.id.buttonSubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String creditHours = editCreditHours.getText().toString();
                int hours = checkInteger(creditHours);

                if (editCourseNumber.getText().toString().isEmpty()) {
                    Toast.makeText(getContext(), "Enter Course Number", Toast.LENGTH_SHORT).show();
                } else if (editCourseName.getText().toString().isEmpty()) {
                    Toast.makeText(getContext(), "Enter Course Name", Toast.LENGTH_SHORT).show();
                } else if (editCreditHours.getText().toString().isEmpty() || hours == -1) {
                    Toast.makeText(getContext(), "Enter Credit Hours correctly", Toast.LENGTH_SHORT).show();
                } else if (radioGroup.getCheckedRadioButtonId() == -1) {
                    Toast.makeText(getContext(), "Select Grade", Toast.LENGTH_SHORT).show();
                } else {
                    radioButton = view.findViewById(radioGroup.getCheckedRadioButtonId());
                    Course course = new Course(editCourseNumber.getText().toString(),
                            editCourseName.getText().toString(),
                            hours,
                            radioButton.getText().toString());
                    mListener.gotoGradesFragment(course);
                }
            }
        });
        view.findViewById(R.id.buttonCancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.gotoGradesFragment();
            }
        });

        return view;
    }

    private int checkInteger(String creditHours) {
        if (creditHours.isEmpty()) {
            return -1;
        }
        try {
            int hours = Integer.parseInt(creditHours);
            return hours;
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    AddCourseFragment.AddCourseListener mListener;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener = (AddCourseListener) (context);
    }

    interface AddCourseListener {
        void gotoGradesFragment();
        void gotoGradesFragment(Course couse);
    }
}